# Pulse reporting contracts

`pulse-reporting-types` contains shared reporting DTOs. Rust serde definitions own the wire shape; ts-rs generates the types-only npm package `@ignition-is-go/pulse-reporting-types`.

Services own receipt validation, observation expiry, identities, transport envelopes and display policy. Recorder tagged signalling evidence and flat SFU signalling status are separate contracts.

```sh
cargo test --workspace --all-features --locked
cargo run -p export-types --locked
cargo run -p export-types --locked -- --check
npm pack --ignore-scripts
```

The default Rust package depends on serde only. The optional `typescript` feature enables generation with ts-rs 12.0.1. Generated declarations are committed and require no Rust installation in npm consumers.

Private Git consumers should pin an immutable source commit and commit their lockfiles. Builds need authenticated access to this repository. A packed npm artifact can instead be vendored with its source commit and checksum. This repository does not publish to a registry automatically.

JSON counters retain the existing numeric representation. JavaScript producers must keep integers within the safe integer range; no bigint conversion is introduced. SFU error and packetsLost fields accept omission or null, matching existing JS and Rust producers.
