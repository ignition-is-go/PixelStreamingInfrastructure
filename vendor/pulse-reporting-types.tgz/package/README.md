# Pulse reporting contracts

`pulse-reporting-types` contains shared reporting DTOs. Rust serde definitions own the wire shape; ts-rs generates the types-only npm package `@ignition-is-go/pulse-reporting-types`.

Services own receipt validation, observation expiry, identities, transport envelopes and display policy. Recorder tagged signalling evidence and flat SFU signalling status are separate contracts.

`SourceConnectionObservation` separates a client's signalling connection from video RTP packet reception. Its generation identifies the source session; packet counters restart when the service reconnects. RTP reception distinguishes waiting for the first packet, receiving packets, stalled reception, and a stopped session. It does not report decoding or frame presentation. Services can make this observation optional in their envelopes when older publishers do not report it.

```sh
cargo test --workspace --all-features --locked
cargo run -p export-types --locked
cargo run -p export-types --locked -- --check
npm pack --ignore-scripts
```

The default Rust package depends on serde only. The optional `typescript` feature enables generation with ts-rs 12.0.1. Generated declarations are committed and require no Rust installation in npm consumers.

Private Git consumers should pin an immutable source commit and commit their lockfiles. Builds need authenticated access to this repository. A packed npm artifact can instead be vendored with its source commit and checksum. This repository does not publish to a registry automatically.

JSON counters retain the existing numeric representation. JavaScript producers must keep integers within the safe integer range; no bigint conversion is introduced. SFU error and packetsLost fields accept omission or null, matching existing JS and Rust producers.

Viewer reporting DTOs retain the existing snake_case measurement fields and camelCase observation envelopes. Audio and video track evidence are independent. `no_progress` describes a reported track without progress; services decide whether that is expected. Older readings without an audio packet count and older observations without track states remain readable. Missing track states default to `unreported`. Viewer identity, receipt validation, aggregate policy, and observation expiry remain service responsibilities.

## Camera relay observations

`camera::CameraRelayObservation` reports the compositor's source data channel and
its negotiated SFU peer channels. `peer_id` is the actual signalling player ID;
consumers join it to publisher identity observations before assigning an SFU.
Counters cover the source generation. A successful forwarded payload means the
channel accepted the send. Source messages and recognized `StreamCameraState`
messages are independent receive evidence, including unsolicited state updates.
None establishes a correlated reply or application of a command. Cached replay
is not a new source receive. Idle cameras do not require periodic traffic.

The service reports channel lifecycle and owns observation freshness. Consumers
retain stale details but must gate line health on the reporting subscription.

Viewer progress deltas compare the same inbound RTP report across advancing samples. A missing first sample, missing counter, replaced track, or counter reset has no delta (`null` or omitted). A measured zero delta means no progress; a positive delta means progress. Absolute counters remain available independently. Producers sample progress; the receiving service interprets track and aggregate health and expires reports. A negotiated track that has never received media does not establish that the track is expected.

## Stream inventory

`stream::StreamInventorySnapshot` contains the signalling server's complete current
registry. A stream's identity is its reporting source plus `streamerId`; the ID
alone is not globally unique. `producerKind` distinguishes a direct streamer from
an SFU. `availableToPlayers` is the registry's `streaming` predicate used by the
player-protocol `listStreamers` response. It means listed for discovery, not
guaranteed subscription readiness: the signalling subscribe handler does not
enforce that predicate and may reject requests for other reasons such as capacity.
`upstreamStreamerId` reports an SFU's actual upstream subscription when known,
independently of listing.

The inventory establishes neither media delivery nor browser reception. Viewer
health reports remain separate; missing reception reports do not establish zero
viewers. An empty current inventory means no registry entries, while an absent or
stale inventory is a reporting-state fact owned by the enclosing service. Picker
pinning and visibility filters are consumer policy, not registry availability.
