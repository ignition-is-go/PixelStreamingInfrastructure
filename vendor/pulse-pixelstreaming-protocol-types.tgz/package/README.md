# pulse-pixelstreaming-protocol-types

Signalling registry, SFU signalling and RTP transport measurements.

Generated from the corresponding Rust domain contract crate in this repository.
This package contains TypeScript declarations only, with no runtime code or dependencies.
Observation primitive aliases are generated from `pulse-observation-types`.
They retain the same structural definitions across both domain packages.

Services own validation, expiry and interpretation; consumers own presentation.
